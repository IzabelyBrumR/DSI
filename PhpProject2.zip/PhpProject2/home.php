<!DOCTYPE html>
<html>
    <?php
        require_once './controller/autenticationController.php';
    ?>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <title>Netflix</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" integrity="sha512-BnbUDfEUfV0Slx6TunuB042k9tuKe3xrD6q4mg5Ed72LTgzDIcLPxg6yI2gcMFRyomt+yJJxE+zJwNmxki6/RA==" crossorigin="anonymous" />
        
        <style>
            .logo {
                position: relative;
                z-index: 2;
                height: 90px;
            }

            .logo img {
                width: 170px;
                position: absolute;
                top: 20px;
                left: 40px;
            }
            .div.box {
                display: inline-block;
            }
            .nome {
                color: #ffffff;
                font-size: 50px;
                display: flex;
                margin-left: 4.5%;
                text-align: center;
                align-items: center;    
                margin-right: 29.5%;
            }
            .assistindo
        </style>

    </head>
    <body>
        <div class="fundo">
            <div class="logo">
                <a href="#"><img src="img/logo.png" alt="logo"></a>
            </div>

            <div class="assistindo">
                <h1>Quem está assistindo?</h1>
                <div class="">
                    <div>
                    </div>

    <form action ="home.php" method ="GET">                
        <span class="box">
            <img src="img/iza/capaIza.jpg" width="150px" height="150px"/>
        </span>
        <span class="box">
            <img src="img/lo/capa.jpg" width="200px" height="200px"/>
        </span>
        <span class="box">
            <img src="img/kids/capaKids.jpg" width="200px" height="200px"/>
        </span>
    </form>
            <div class ="name">
                      <div class="name">
                            <p>IZA</p>
                      </div>
                      <div class="name">
                            <p>LORENZO</p>
                      </div>
                      <div class="name">                                
                            <p>KIDS</p>
                      </div>  
            </div>

                 
            </div>
            <button class="config"> Configurações</button>
        </div>
    </div>

        <?php
        if (isset($_GET["id"])) {
            $clickedUserId = $_GET["id"];
        }
        ?>

    </body>
</html>

    