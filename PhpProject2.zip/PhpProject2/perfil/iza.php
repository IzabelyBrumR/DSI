<section class="main-container" >
        <div class="location" id="home">

            <h1 id="movies">Filmes</h1>
                <div class="box">
                    <img src="../img/iza/BarracaDoBjo.jpg" alt=""/>
                    <img src="../img/iza/FeraMar.jpeg" alt=""/>
                    <img src="../img/iza/OndeEstaSeg.png" alt=""/>
                    <img src="../img/iza/Shrek2.jpg" alt=""/>
                    <img src="../img/iza/avatar.jpeg" alt=""/>
                    <img src="../img/iza/fuja.jpg" alt=""/>
                    <img src="../img/iza/goosebumps.jpg" alt=""/>
                </div>

            <h1 id="originals">Séries</h1>
                <div class="box">
                    <img src="../img/iza/CaçadoresDeTrolls.jpeg" alt=""/>
                    <img src="../img/iza/GossipGirl.jpg" alt=""/>
                    <img src="../img/iza/OuterBanks.jpeg" alt=""/>
                    <img src="../img/iza/arrow.jpeg" alt=""/>
                    <img src="../img/iza/demonSlayer.jpg" alt=""/>
                    <img src="../img/iza/elite.jpg" alt=""/>
                    <img src="../img/iza/julie.jpeg" alt=""/>
                </div>
</body>
</html>