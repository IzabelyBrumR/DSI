<section class="main-container" >
        <div class="location" id="home">

            <h1 id="movies">Filmes</h1>
                <div class="box">
                    <img src="../img/kids/KungFuPanda.jpeg" alt=""/>
                    <img src="../img/kids/casaMonstro.jpeg" alt=""/>
                    <img src="../img/kids/dandoOnda.jpeg" alt=""/>
                    <img src="../img/kids/emoji.jpeg" alt=""/>
                    <img src="../img/kids/sing.jpeg" alt=""/>
                    <img src="../img/kids/smurfs.jpg" alt=""/>
                    <img src="../img/kids/trolls.jpg" alt=""/>
                </div>

            <h1 id="originals">Séries</h1>
                <div class="box">
                    <img src="../img/kids/barbie.jpeg" alt=""/>
                    <img src="../img/kids/bobEsponja.jpg" alt=""/>
                    <img src="../img/kids/boruto.jpeg" alt=""/>
                    <img src="../img/kids/everAfter.jpeg" alt=""/>
                    <img src="../img/kids/mylittlePony.jpg" alt=""/>
                    <img src="../img/kids/mashaUrso.jpg" alt=""/>
                    <img src="../img/kids/pokemon.jpg" alt=""/>
                </div>
</body>
</html>