<section class="main-container" >
        <div class="location" id="home">

            <h1 id="movies">Filmes</h1>
                <div class="box">
                    <img src="../img/lo/GenteGrande.jpeg" alt=""/>
                    <img src="../img/lo/arremessando alto.jpg" alt=""/>
                    <img src="../img/lo/jogosVorazes.jpg" alt=""/>
                    <img src="../img/lo/oHomem.jpeg" alt=""/>
                    <img src="../img/lo/os7.jpeg" alt=""/>
                    <img src="../img/lo/poço.jpg" alt=""/>
                    <img src="../img/lo/quebrandoAbanca.jpg" alt=""/>
                </div>

            <h1 id="originals">Séries</h1>
                <div class="box">
                    <img src="../img/lo/Atirador.jpg" alt=""/>
                    <img src="../img/lo/TWD.jpg" alt=""/>
                    <img src="../img/lo/breaking-bad.jpg" alt=""/>
                    <img src="../img/lo/f1.jpg" alt=""/>
                    <img src="../img/lo/lucifer.jpeg" alt=""/>
                    <img src="../img/lo/suits.jpg" alt=""/>
                    <img src="../img/lo/theWitcher.jpeg" alt=""/>
                </div>
</body>
</html>