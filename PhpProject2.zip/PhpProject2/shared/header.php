<style>

    header {
    padding: 20px 20px 0 20px;
    position: fixed;
    top: 0;
    display: grid;
    grid-gap:5px;
    grid-template-columns: 1fr 4fr 1fr;
    grid-template-areas:
    "nt mn mn sb . . . ";
    background-color: var(--primary);
    width: 100%;
    margin-bottom: 0px;
    font-weight: bold;
    }

    .netflixLogo {
    grid-area: nt;
    object-fit: cover;
    width: 100px;
    max-height: 100%;

    padding-left: 30px;
    padding-top: 0px;
    }

    .netflixLogo img {
    height: 35px;
    }

    #logo {
    color: #E50914;
    margin: 0;
    padding: 0;
    }


    .main-nav {
    grid-area: mn;
    padding: 0 30px 0 20px;
    }

    .main-nav a {
    color: var(--light);
    text-decoration: none;
    margin: 5px;
    }

    .main-nav a:hover {
    color: var(--dark);
    }

    .sub-nav {
    grid-area: sb;
    padding: 0 40px 0 40px;
    }

    .sub-nav a {
    color: var(--light);
    text-decoration: none;
    margin: 5px;
    }

    .sub-nav a:hover {
    color: var(--dark);
    }

    .user{
        width: 15px;
    }
    
</style>

<header>
    <div class="netflixLogo">
        <a id="logo" href="home.php"><img src="img/logo.png" alt="Logo"></a>
    </div>      
    <nav class="main-nav">                
        <a href="#inicio">Início</a>
        <a href="#series">Séries</a>
        <a href="#filmes">Filmes</a>
        <a href="#bombado">Bombado</a>
        <a href="#lista">Minha Lista</a>
        <a href="#idiomas">Navegador por Idiomas</a>

    </nav>
    <nav class="sub-nav">
        <a href="#"><i class="fas fa-search sub-nav-logo"></i></a>
        <a href="#"><i class="fas fa-bell sub-nav-logo"></i></a>
        <a href="#">Conta</a>   
       
        
           </nav>      
</header>
