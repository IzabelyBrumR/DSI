<!DOCTYPE html>
<html>
    <head>
        <title>Netflix</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        
        <style>
            body{
                font-family: 'Arial', sans-serif;
            }

            .fundo{
                background-image:url("img/fundoNetflix.jpg");
            }

            .fundo::before{
                content: "";
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: black;
                opacity: 0.6;
                z-index: 1;
            }

            .logo {
                position: relative;
                z-index: 2;
                height: 90px;
            }

            .logo img {
                width: 170px;
                position: absolute;
                top: 20px;
                left: 40px;
            }


            h1{
                color: white;
                font-weight: bold;
            }
            .text{
                justify-content: space-between;
            }

            .form-control{
                margin-bottom: 20px;
                width: 100%;
                height: 50px;
                border-radius: 5px;
                border-color: gray;
                padding: 10px;
                font-size: inherit;
                background-color: #282828;
                color:white;             
            }
            
   
            .login-fundo{
                position: relative;
                z-index: 2;
                width: 450px;
                height: 650px;
                background: rgb(0, 0, 0, 0.65);
                margin: 0 auto;
                margin-right: auto; /* Adicione esta linha */
                display: flex;
                flex-direction: column;
                justify-content: flex-start;
                align-items: flex-start;
                text-align: left;
                padding: 60px 65px;

            }

            .gray{
                color: gray;
            }
            .sobre {
                font-size: 0.8em;
                line-height: 1.1em;
                color:gray;
            }

            .sobre a {
                color: #116ce4;
            }

            a {
                color: #fff;
                text-decoration: none;
            }

            .btn{
                border-radius: 3px;
                margin-bottom: 12px;
                background-color: red;
                padding: 12px 22px;
                font-weight: bold;
            }
            
            .form-check{
                color: #cccccc;
                font-size: 0.8rem;
                
            }
            
            
            .form-check a{
                color: #cccccc;
                margin-left:27%;
                
            }
            
            .alert-danger{
                
                background-color: red;
                border: none;
            }
            
            .center-row {
    display: flex;
    justify-content: center;
}
        </style>
    </head>
    <body class="fundo">

        <div class="logo">

            <img src="img/logo.png" alt=""/>

        </div>

        <div class="center-row">      
            <div class="col-md-4">
                <div class="login-fundo">
                   <form method="post" action="controller/loginController.php">   
                        <div class="row">
                            <div >
                                <h1>Entrar</h1>
                            </div>

                            <div class="mb-3 mt-3">
                                
                                   
                                    <input type="email" class="form-control" id="email" placeholder="Email Ou Número de Telefone" name="email" required="">
                                  
                                    <input type="password" class="form-control" id="senha" placeholder="Senha" name="senha" required="">
                               </div>
                                <div class="d-grid">                                   
                                    <input type="submit" value="Entrar "
                                           class="btn btn-danger">
                                </div>
                                </div>
                                <div class="text">

                                        <label class="form-check">
                                        <input class="form-check-input"name="lem_senha" type="checkbox" value="lem_senha"/>
                                        <p>Lembre-se de mim <a href="#">Precisa de Ajuda ?</a></p>
                                        
                                        </label>
                                    
                                    </td><br><br><br><br>

                                    <div class="text">

                                        <td>
                                            <p class="gray">Novo por aqui? <a href="https://www.netflix.com/signup?locale=pt-BR">Assine Agora</a> </p>

                                        </td>

                                    </div>

                                    <div class="sobre">
                                        <p>
                                            Está página é protegida pelo Google reCAPTCHA para garantir que você não é um robo. <a href="#">Saiba Mais.</a> 
                                        </p>
                                    </div>  


                                </div>

                            
                   </form>
</div>
                </div>

            </div>
            <div class="col-md-4"> </div>
    </body>
</html>
