<?php 
    require_once './shared/header.php';
?>
<body>
    <div class="row">
        <div class="col-md-4"> </div>
        <div class="col-md-4">
            <form  method="post" action="controller/loginController.php">   
                <div class="row" style="
                 margin: 30px 30px 30px 30px; padding: 20px">
                <div class="mb-3 mt-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" id="email" 
                    placeholder="Insira seu email" name="email" required="">
                </div>
                <div class="mb-3 mt-3">
                    <label for="senha" class="form-label">Senha:</label>
                    <input type="password" class="form-control" id="senha" 
                    placeholder="Insira sua senha" name="senha" required="">
                </div>
                <div class="d-grid">
                    <input type="submit" value="Logar"
                    class="btn btn-outline-success" >
                </div>
            <div class="d-grid">