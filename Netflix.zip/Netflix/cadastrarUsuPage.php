<!DOCTYPE html>
<html>
    <head>
    <head>
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>

        <style>             
            .logo {
                position: relative;
                z-index: 2;
                height: 90px;
            }

            .logo img {
                width: 170px;
                position: absolute;
                top: 20px;
                left: 40px;
            }
            body {
                font-family: 'Arial', sans-serif;
                overflow: hidden;
            }
            h2 {
                color: black;
                font-weight: bold;
            }

            .form-control {
                margin-bottom: -2vh;
                width: 100%;
                height: 50px;
                border-radius: 5px;
                border-color: black;
                padding: 10px;
                font-size: inherit;
                background-color: white;
                color: white;
            }
            .center-row {
                display: flex;
                justify-content: center;
            }
            .cadastro-fundo {
                position: relative;
                z-index: 2;
                width: 50vh;
                height: 65vh;
                background: white;
                margin: 0 auto;
                margin-right: auto;
                display: flex;
                flex-direction: column;
                justify-content: flex-start;
                align-items: flex-start;
                text-align: left;
                padding: 8vh 2vh;
            }
            .passo{
                font-weight: bold;
                font-size: 13px;               
            }

        </style>         
              
    </head>
    <body>
        <div class="logo">
            <img src="img/logo.png" alt=""/>
        </div>   
        
        <div class="center-row">      
            <div class="col-md-3">
                <div class="cadastro-fundo">
                    <form  method="post" action="controller/loginController.php">   
                        <div class="row">
                            <div>
                                <h4 class="passo">PASSO 2 DE 3</h4>
                            </div>
                                
                            <div>
                                <h2>Crie uma senha para iniciar sua assinatura</h2>
                            </div>
                            
                            <div>
                                <h4 class="form">Faltam só mais alguns passos!</h4>
                            </div>
                            
                            <div class="mb-3 mt-3">
                                <input type="email" class="form-control" id="email" 
                                       placeholder="Email" name="email" required="">
                            </div>
                            <div class="mb-3 mt-3">
                                <input type="password" class="form-control" id="senha" 
                                       placeholder="Senha" name="senha" required="">
                            </div>
                            
                        </div>
                    </form>  

                </div>
            </div>

        </div>
    </body>
</html>
