<?php

if($_POST){
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    @$lembrar = $_POST['lembrar'];
    
    $dados = array('email'=>'a@a','senha'=>'12345');//email e senha
    
    if ($email == $dados['email'] && $senha == $dados['senha']){
        session_start();// sessao iniciada
        
        $_SESSION['login'] = $email;
        
         if(isset($lembrar)){//cookies vao lembrar
            if($lembrar == 1){
                
                setcookie('email', $email, time() + (86400 * 30), "/"); //tempo de vida do cookie
            }
        }else{
          
            if (isset($_COOKIE['email'])) {
               
                setcookie("email", "", time()  - (86400 * 30), "/");//mata o cookie
            }
        }
        header('location:../home.php');
    }else{
        header('location:../index.php?cod=171');
        echo ('<span style="color:darkorange;">Senha ou email invalido/span>');//caso senha e email estejam errados
    }
}else{
    header('location:../index.php');
}
