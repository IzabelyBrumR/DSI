<?php

//Se vier qualquer coisa via get
if ($_POST) {
    //print_r($_GET);
    //entra aqui e pega os valores.
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $lembrar = $_POST['lembrar'];
    
    //abrir a conexao
    $dados = array('email' => 'a@a', 'senha' => '12345');
    //executar a consulta
    if ($email == $dados['email'] && $senha == $dados['senha']) {
        
        session_start();
        
        $_SESSION['login'] = $email;

        if($lembrar == true){
            setcookie("Netflix",$email,time()+9999,"/");
        }
        
        header('location:../home.php');
    } else {
        //Login inválido 
        header('location:../index.php?cod=171');
    }
}
?>
