
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Netflix</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js" integrity="sha384-3LK/3kTpDE/Pkp8gTNp2gR/2gOiwQ6QaO7Td0zV76UFJVhqLl4Vl3KL1We6q6wR9" crossorigin="anonymous"></script>


    <style>

        :root {
            --primary: #141414;
            --light: #F3F3F3;
            --dark: 	#686868;
        }

        body {
            width: 100px;
            min-height: 100px;

            margin: 0;
            padding: 0;
            background-color: var(--primary);
            color: var(--light);
            font-family: Arial, Helvetica, sans-serif;
            box-sizing: border-box;
            line-height: 1.4;
        }
        h1 {
            padding-top: 60px;
        }

        .wrapper {
            margin: 0;
            padding: 0;
            margin-left: 2vh;
            margin-top: 5vh;
        }

        .main-container {
            padding: 50px;
        }
        #home{
            display: flex;
        }

        .box img {
            border-radius: 2px;
            transition: .3s;
            width: 335px;
            height: 200px;
            z-index: 0;
            margin: 10px;

        }
        .box img:hover{
            transform: scale(1.4);
        }
        .link {
            padding: 50px;
        }

        .sub-links ul {
            list-style: none;
            padding: 0;
            display: grid;
            grid-gap: 20px;
            grid-template-columns: repeat(4, 1fr);
        }

        .sub-links a {
            color: var(--dark);
            text-decoration: none;
        }

        .sub-links a:hover {
            color: var(--dark);
            text-decoration: underline;
        }

        .logos a{
            padding: 10px;
        }

        .logo {
            color: var(--dark);
        }

    </style>
</head>
<?php
require_once './controller/autenticationController.php';
require_once './shared/header.php';
$filmes = array(
    array(
        'img' => './img/iza/arrow.jpeg',
        'tipo' => 'iza',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/iza/Shrek2.jpg',
        'tipo' => 'iza',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/iza/avatar.jpeg',
        'tipo' => 'iza',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/iza/BarracaDoBjo.jpg',
        'tipo' => 'iza',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/iza/CaçadoresDeTrolls.jpeg',
        'tipo' => 'iza',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/iza/demonSlayer.jpg',
        'tipo' => 'iza',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/iza/elite.jpg',
        'tipo' => 'iza',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/iza/FeraMar.jpeg',
        'tipo' => 'iza',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/iza/fuja.jpg',
        'tipo' => 'iza',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/iza/goosebumps.jpg',
        'tipo' => 'iza',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/iza/GossipGirl.jpg',
        'tipo' => 'iza',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/iza/julie.jpeg',
        'tipo' => 'iza',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/iza/OndeEstaSeg.png',
        'tipo' => 'iza',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/iza/OuterBanks.jpeg',
        'tipo' => 'iza',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/barbie.jpeg',
        'tipo' => 'kids',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/bobEsponja.jpg',
        'tipo' => 'kids',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/boruto.jpeg',
        'tipo' => 'kids',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/casaMonstro.jpeg',
        'tipo' => 'kids',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/kids/dandoOnda.jpeg',
        'tipo' => 'kids',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/kids/emoji.jpeg',
        'tipo' => 'kids',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/kids/everAfter.jpeg',
        'tipo' => 'kids',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/KungFuPanda.jpeg',
        'tipo' => 'kids',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/kids/mashaUrso.jpg',
        'tipo' => 'kids',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/mylittlePony.jpg',
        'tipo' => 'kids',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/pokemon.jpg',
        'tipo' => 'kids',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/kids/sing.jpeg',
        'tipo' => 'kids',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/kids/smurfs.jpg',
        'tipo' => 'kids',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/kids/trolls.jpg',
        'tipo' => 'kids',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/arremessando alto.jpg',
        'tipo' => 'lo',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/Atirador.jpg',
        'tipo' => 'lo',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/lo/breaking-bad.jpg',
        'tipo' => 'lo',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/lo/f1.jpg',
        'tipo' => 'lo',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/lo/GenteGrande.jpeg',
        'tipo' => 'lo',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/jogosVorazes.jpg',
        'tipo' => 'lo',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/lucifer.jpeg',
        'tipo' => 'lo',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/lo/oHomem.jpeg',
        'tipo' => 'lo',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/os7.jpeg',
        'tipo' => 'lo',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/poço.jpg',
        'tipo' => 'lo',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/quebrandoAbanca.jpg',
        'tipo' => 'lo',
        'categoria' => 'filme'
    ),
    array(
        'img' => './img/lo/suits.jpg',
        'tipo' => 'lo',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/lo/theWitcher.jpeg',
        'tipo' => 'lo',
        'categoria' => 'serie'
    ),
    array(
        'img' => './img/lo/TWD.jpg',
        'tipo' => 'lo',
        'categoria' => 'serie'
    ),
);
?>

<body>
    <div class="wrapper"> 
        <div class="location" id="home">
            <?php
            $i = 1;
            foreach ($filmes as $filme) {
                if ($filtro == 'todos' || $filtro == $filme['categoria']) {
                    if ($perfilSelecionado == 'Kids' && $filme['tipo'] == 'kids') {
                        $i++;
                        echo '<div class="box">';
                        echo '<img class="img" src="' . $filme['img'] . '"/>';
                        echo '</div>';
                        if ($i % 6 == 0) {
                            echo('</div>');
                            echo('<div class="location" id="home">');
                            $i = 1;
                        }
                    }
                    if ($perfilSelecionado == 'Lorenzo' && $filme['tipo'] == 'lo') {
                        $i++;
                        echo '<div class="box">';
                        echo '<img class="img" src="' . $filme['img'] . '"/>';
                        echo '</div>';
                        if ($i % 6 == 0) {
                            echo('</div>');
                            echo('<div class="location" id="home">');
                            $i = 1;
                        }
                    }
                    if ($perfilSelecionado == 'Iza' && $filme['tipo'] == 'iza') {
                        $i++;
                        echo '<div class="box">';
                        echo '<img class="img" src="' . $filme['img'] . '"/>';
                        echo '</div>';
                        if ($i % 6 == 0) {
                            echo('</div>');
                            echo('<div class="location" id="home">');
                            $i = 1;
                        }
                    }
                }
            }
            ?>
        </div>
    </div>






