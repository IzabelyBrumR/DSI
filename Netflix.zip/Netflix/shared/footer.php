
<style>
    footer {
        position: fixed;   
        z-index: 10;
        background: rgba(0, 0, 0, 0.65);
        width: 100%;
        height: 100px;
        bottom: 0;
        
    }

    .ftr-content {
        margin-left: 20%;
        padding-top: 35px;
        
    }

    .ftr-content p {
        color: #999;
    }
</style>

</div>

 <footer>      
                <div class="ftr-content">
                  
                    <p> Dúvidas? Ligue 0800 591 2876</p>      
                   
                </div>
               
            </footer>

</div>
</body>
</html>