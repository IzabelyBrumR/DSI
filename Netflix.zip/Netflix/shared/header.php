<html>
<style>
    body{
        width:100%;
        height:100%;
    }
    header {
        width:300vh;
        background: #000;
        display: flex;
    }
    
    #netflixLogo{
        height: 60%;
    }
    .netlog a{
        width: 100%;
        height: 100%;
    }
    .netlog{
        display: flex;
        justify-content: center;
        align-items: center;
    }
    a{
        text-decoration: none;
        color: white;
        padding: 0;
        margin-top: auto;
        margin-bottom: auto;
        margin-left: 2%;
    }
    .fa-search{
        margin-left: 15vh;
    }
</style>

<header>
    <?php
        $perfilSelecionado = isset($_GET['account']) ? $_GET['account'] : 'Iza';
        $filtro = isset($_GET['filtro']) ? $_GET['filtro'] : 'todos';
    ?>
        <div class="netlog">
            <center>
            <a href="home.php">
                <img src="img/logo.png" alt="Logo" id="netflixLogo">
            </a>
            </center>
        </div>               
        <a href="filme.php?account=<?php echo $perfilSelecionado ?>">Início</a>
        <a href="filme.php?account=<?php echo $perfilSelecionado ?>&filtro=serie">Séries</a>
        <a href="filme.php?account=<?php echo $perfilSelecionado ?>&filtro=filme">Filmes</a>
        <a href="#bombando">Bombando</a>
        <a href="#lista">Minha Lista</a>
        <a href="#idiomas">Navegador por Idiomas</a>
        <a href="#"><i class="fas fa-search sub-nav-logo"></i></a>
        <a href="#"><i class="fas fa-bell sub-nav-logo"></i></a>
        <a href="./home.php">Conta</a>       
</header>
