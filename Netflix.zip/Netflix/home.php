<!DOCTYPE html>
<html>
    <?php
        require_once './controller/autenticationController.php';
    ?>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <title>Netflix</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" integrity="sha512-BnbUDfEUfV0Slx6TunuB042k9tuKe3xrD6q4mg5Ed72LTgzDIcLPxg6yI2gcMFRyomt+yJJxE+zJwNmxki6/RA==" crossorigin="anonymous" />
        
        <style>
            body{
                background-color: black;
            }
                 
            .logo {
                position: relative;
                z-index: 2;
                height: 90px;
            }

            .logo img {
                width: 170px;
                position: absolute;
                top: 20px;
                left: 40px;
            }
            .div.box {
                display: inline-block;
            }
            .nome {
                color: #ffffff;
                font-size: 30px;
                width: 100%;
                justify-content: center;
            }
            .img {
                width: 100%;
                height: 90%;
            }
            h1{
                font-weight: bold;
                color:#ffffff;
            }
            .col-4{
                display: center;
            
            }

        </style>

    </head>
    <body>
        <div class="fundo">
            <div class="logo">
                <a href="#"><img src="img/logo.png" alt="logo"></a>
            </div>
    </div>

        <?php
        if (isset($_GET["id"])) {
            $clickedUserId = $_GET["id"];
        }
        ?><body>
    <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
            <center><h1 class="mb-5 mt-5">Quem está assistindo?</h1></center><br>
            
            <div class="row">
                    <?php
                    if($_SESSION['login'] == 'a@a'){
                    
                        $result = array(
                        array('nome'=>'Iza',  'img'=>'./img/iza/capa.png'),
                        array('nome'=>'Lorenzo','img'=>'./img/lo/capa.png'),
                        array('nome'=>'Kids','img'=>'./img/kids/capa.jpg')
                        );  
                    }
                    
                    foreach ($result as $data){
                        echo('<div class="col-4">
                                <a href="./filme.php?account='.$data["nome"].'">
                                    <img class="img" src="'.$data["img"].'" alt=""/>
                                    </a>
                                    <br>
                                    <center>
                                        <h3 class="nome" >'.$data["nome"].'</h3>
                                    </center>
                                </div>');
                    }
                    ?>
            </div>
            
            
        </div>
        <div class="col-3"></div>
    </div>

    </body>
</html>

    